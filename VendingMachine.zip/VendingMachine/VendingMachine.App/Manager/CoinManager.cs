﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendingMachine.App.Models;
using Newtonsoft.Json;

namespace VendingMachine.App.Manager
{
    public class CoinManager
    {
        public Boolean ValidateCoin(Coin coin)
        {
            try
            {
                if (coin == null)
                {
                    return false;
                }
                if (string.IsNullOrEmpty(coin.Name) || coin.Size == 0.0d || coin.Weight == 0.0d)
                {
                    return false;
                }
                //Get the list of valid coins.
                var coinJson = File.ReadAllText("../TestData/coinJson.json");
                List<Coin> lstCoin = JsonConvert.DeserializeObject<List<Coin>>(coinJson);
                Coin validatedCoin = lstCoin.FirstOrDefault(x => x.Name.Equals(coin.Name, StringComparison.OrdinalIgnoreCase) && x.Size == coin.Size && x.Weight == coin.Weight);

                if (validatedCoin == null)
                {
                    // Coin is invalid & rejected . Place to outer coin box.
                }
                return true;
            }
            catch (Exception)
            {
                // Logger
            }
            return false;
        }
    }
}
