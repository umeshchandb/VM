﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendingMachine.App.Models;

namespace VendingMachine.App.Manager
{
    public class ProductManager
    {
        public List<Product> GetProductsByPrice(double price)
        {
            List<Product> lstProducts = new List<Product>();
            try
            {
                if (price == 0.0d)
                {
                    return lstProducts;
                }

                List<Product> allProducts = GetAllProducts();
                lstProducts = allProducts.Where(x => x.Price <= price).ToList();
            }
            catch (Exception)
            {
                //Logger
            }
            return lstProducts;
        }
        public Product GetProductByName(string productName)
        {
            Product product = new Product();
            try
            {
                if (string.IsNullOrEmpty(productName))
                {
                    return product;
                }
                List<Product> allProducts = GetAllProducts();
                product = allProducts.FirstOrDefault(x => x.Name.Equals(productName, StringComparison.OrdinalIgnoreCase));
            }
            catch (Exception)
            {
                //Logger
            }
            return product;
        }
        private List<Product> GetAllProducts()
        {
            var productsJson = File.ReadAllText("../TestData/productJson.json");
            List<Product> allProducts = JsonConvert.DeserializeObject<List<Product>>(productsJson);
            return allProducts;
        }
    }
}
