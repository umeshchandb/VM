﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine.App.Models
{

    //public enum Currency
    //{
    //    USD,
    //    INR,
    //    GBP,
    //    EUR
    //}
    public class Product
    {
        public string Name { get; set; }
        public double Price { get; set; }
        public string Currency { get; set; }
    }
}
