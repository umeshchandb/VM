﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendingMachine.App.Manager;
using VendingMachine.App.Models;

namespace VendingMachine.App
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Please insert the coin");
            //Get the coin from machine.
            Coin coin = new Coin() { Name = "Nickels", Size = 1.0, Weight = 5.0 };
            CoinManager objCoinManager = new CoinManager();
            Boolean isValidCoin = objCoinManager.ValidateCoin(coin);
            if (!isValidCoin)
            {
                Console.WriteLine("Invalid Coin");
            }
            // Get producs
            ProductManager objProductManager = new ProductManager();
            //coin.Weight as Price
            List<Product> allProducts = objProductManager.GetProductsByPrice(coin.Weight);
            // display all the products which can be bought. Let user select the product.
            foreach (var item in allProducts)
            {
                Console.WriteLine(item.Name);
            }
            //get the  selected ptoduct which will be despensed.
            Product product = objProductManager.GetProductByName("Cola");
            Console.WriteLine($"Your product is:{product.Name} is dispensed. Thank you");
            Console.WriteLine("Enter another coin to shop more.");

        }
    }
}
