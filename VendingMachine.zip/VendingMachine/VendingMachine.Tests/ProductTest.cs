﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace VendingMachine.Tests
{
    [TestClass]
    public class ProductTest
    {
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
