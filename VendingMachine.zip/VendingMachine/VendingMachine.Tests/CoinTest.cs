﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace VendingMachine.Tests
{
    [TestClass]
    public class CoinTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
